var searchData=
[
  ['buffer_5fsize_0',['buffer_size',['../namespace_cross_tok.html#a4522945bf0b38e0479731f0b77803c8b',1,'CrossTok']]]
];
