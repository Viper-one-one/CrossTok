var searchData=
[
  ['description_0',['description',['../namespacesetup.html#aedf461ec52a946bda975938ba0b93ec0',1,'setup']]]
];
