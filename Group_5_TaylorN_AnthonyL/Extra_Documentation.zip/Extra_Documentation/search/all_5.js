var searchData=
[
  ['main_0',['main',['../namespace_cross_tok.html#aa337b2a3c7be2962e19a6516088c0b6d',1,'CrossTok']]],
  ['max_5fconn_1',['max_conn',['../namespace_cross_tok.html#acd01dd741b91bea122cadfd992b57c80',1,'CrossTok']]]
];
