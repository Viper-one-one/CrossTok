var searchData=
[
  ['receive_5fconnections_0',['receive_connections',['../namespace_cross_tok.html#a1e4b04e703e415154ed0d3e753d4db0e',1,'CrossTok']]],
  ['receive_5fmessages_1',['receive_messages',['../namespace_cross_tok.html#a864ad7c54136ab3f716da99ad30262e1',1,'CrossTok']]]
];
