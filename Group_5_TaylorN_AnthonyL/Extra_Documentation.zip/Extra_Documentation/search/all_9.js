var searchData=
[
  ['send_5fmessage_0',['send_message',['../namespace_cross_tok.html#a5a4242b3ecac22e4093e01cf5ce8d026',1,'CrossTok']]],
  ['setup_1',['setup',['../namespacesetup.html',1,'']]],
  ['setup_2epy_2',['setup.py',['../setup_8py.html',1,'']]]
];
