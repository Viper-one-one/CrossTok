var searchData=
[
  ['send_5fmessage_0',['send_message',['../namespace_cross_tok.html#a5a4242b3ecac22e4093e01cf5ce8d026',1,'CrossTok']]]
];
