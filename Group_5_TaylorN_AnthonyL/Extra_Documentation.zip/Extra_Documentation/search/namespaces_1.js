var searchData=
[
  ['setup_0',['setup',['../namespacesetup.html',1,'']]]
];
